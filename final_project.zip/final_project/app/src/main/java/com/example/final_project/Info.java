package com.example.final_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Info extends AppCompatActivity implements View.OnClickListener {
    Button btngames, btntable, btnmap;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        fragmentManager = getSupportFragmentManager();
        user = (User) getIntent().getExtras().getSerializable("user");

        btnmap = findViewById(R.id.mapbtn);
        btngames = findViewById(R.id.gamesbtn);
        btntable = findViewById(R.id.tablebtn);

        btnmap.setOnClickListener(this);
        btntable.setOnClickListener(this);
        btngames.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if (view == btngames) {
            GamesFragment gamesFragment = (GamesFragment) fragmentManager.findFragmentByTag("games");
            if (gamesFragment == null) {
                gamesFragment = new GamesFragment();
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container, gamesFragment, "games");
                fragmentTransaction.commit();
            }
        }

        if (view == btntable) {
            TableFragment tableFragment = (TableFragment) fragmentManager.findFragmentByTag("table");
            if (tableFragment == null) {
                tableFragment = new TableFragment();
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container, tableFragment, "table");
                fragmentTransaction.commit();
            }
        }

        if (view == btnmap) {
            DirectionsFragment directionsFragment = (DirectionsFragment) fragmentManager.findFragmentByTag("directions");
            if (directionsFragment == null) {
                directionsFragment = new DirectionsFragment();
                fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container, directionsFragment, "directions");
                fragmentTransaction.commit();
            }
        }

        }
    }
