package com.example.final_project;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_project.R;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TableFragment extends Fragment {

    private RecyclerView recyclerView;
    private TableAdapter adapter;
    private List<String[]> tableDataList;
    private ProgressBar progressBar;

    public TableFragment() {
        // Required empty public constructor
    }

    public static TableFragment newInstance() {
        return new TableFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_table, container, false);

        recyclerView = rootView.findViewById(R.id.rv);
        progressBar = rootView.findViewById(R.id.progressbar);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        tableDataList = new ArrayList<>();
        adapter = new TableAdapter(tableDataList);
        recyclerView.setAdapter(adapter);

        FetchDataTask fetchDataTask = new FetchDataTask();
        fetchDataTask.execute();

        return rootView;
    }

    private class FetchDataTask extends AsyncTask<Void, Void, List<String[]>> {

        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected List<String[]> doInBackground(Void... voids) {
            List<String[]> tableData = new ArrayList<>();

            try {
                Document document = Jsoup.connect("https://www.eurosport.com/football/liga/standings.shtml").get();
                Elements tableRows = document.select("table.table-main tr");

                for (Element row : tableRows) {
                    Elements columns = row.select("td");

                    if (columns.size() > 0) {
                        String[] rowData = new String[columns.size()];

                        for (int i = 0; i < columns.size(); i++) {
                            rowData[i] = columns.get(i).text();
                        }

                        tableData.add(rowData);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return tableData;
        }

        @Override
        protected void onPostExecute(List<String[]> tableData) {
            progressBar.setVisibility(View.GONE);

            if (tableData.isEmpty()) {
                Toast.makeText(getActivity(), "Failed to fetch table data.", Toast.LENGTH_SHORT).show();
            } else {
                tableDataList.clear();
                tableDataList.addAll(tableData);
                adapter.notifyDataSetChanged();
            }
        }
    }

    public class TableAdapter extends RecyclerView.Adapter<TableAdapter.ViewHolder> {

        private List<String[]> tableData;

        public TableAdapter(List<String[]> tableData) {
            this.tableData = tableData;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_row, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            String[] rowData = tableData.get(position);

            holder.teamTextView.setText(rowData[0]);
            holder.playedTextView.setText(rowData[1]);
            holder.wonTextView.setText(rowData[2]);
            holder.drawnTextView.setText(rowData[3]);
            holder.lostTextView.setText(rowData[4]);
            holder.pointsTextView.setText(rowData[5]);
        }

        @Override
        public int getItemCount() {
            return tableData.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView teamTextView;
            public TextView playedTextView;
            public TextView wonTextView;
            public TextView drawnTextView;
            public TextView lostTextView;
            public TextView pointsTextView;

            public ViewHolder(View itemView) {
                super(itemView);
                teamTextView = itemView.findViewById(R.id.team);
                playedTextView = itemView.findViewById(R.id.played);
                wonTextView = itemView.findViewById(R.id.wins);
                drawnTextView = itemView.findViewById(R.id.draws);
                lostTextView = itemView.findViewById(R.id.loses);
                pointsTextView = itemView.findViewById(R.id.pts);
            }
        }
    }
}
